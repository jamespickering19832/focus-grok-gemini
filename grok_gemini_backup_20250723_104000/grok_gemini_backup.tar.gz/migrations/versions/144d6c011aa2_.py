"""empty message

Revision ID: 144d6c011aa2
Revises: 4791a8c12e1d, 6b2c4d3e5f6a
Create Date: 2025-07-22 09:33:25.895507

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '144d6c011aa2'
down_revision = ('4791a8c12e1d', '6b2c4d3e5f6a')
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
